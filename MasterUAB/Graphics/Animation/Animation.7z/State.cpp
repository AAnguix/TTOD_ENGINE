#include "State.h"
#include "Animation\AnimatorController.h"
#include <luabind/luabind.hpp>
#include "Engine.h"
#include "ScriptManager\ScriptManager.h"
#include "RenderableObjects\RenderableObject.h"
#include "Transition.h"

CState::CState(CAnimatorController* AnimatorController, const std::string &Name, const std::string &Animation, const float &Speed, const std::string &OnEnter, const std::string &OnUpdate, const std::string &OnExit)
:m_AnimatorController(AnimatorController)
,m_Name(Name)
,m_Animation(Animation)
,m_Speed(Speed)
,m_OnEnter(OnEnter)
,m_OnUpdate(OnUpdate)
,m_OnExit(OnExit)
{
	
}

CState::~CState()
{
	std::map<const std::string, CTransition*>::iterator itMap;

	for (itMap = m_Transitions.begin(); itMap != m_Transitions.end(); ++itMap)
	{
		delete itMap->second;
	}
	
	m_Transitions.clear();
}

void CState::OnEnter()
{
	try
	{
		if (!m_OnEnter.empty())
			luabind::call_function<void>(CEngine::GetSingleton().GetScriptManager()->GetLuaState(),
			m_OnEnter.c_str(), m_AnimatorController->GetOwner());
	}
	catch (const luabind::error &e)
	{
		//luabind::object error_msg(luabind::from_stack(e.state(), -1));
		//CEngine::GetSingleton().GetLogManager()->Log(error_msg);
	}
}

void CState::OnExit()
{
	try
	{
		if (!m_OnExit.empty())
			luabind::call_function<void>(CEngine::GetSingleton().GetScriptManager()->GetLuaState(),
			m_OnExit.c_str(), m_AnimatorController->GetOwner());
	}
	catch (const luabind::error &e)
	{
		//luabind::object error_msg(luabind::from_stack(e.state(), -1));
		//CEngine::GetSingleton().GetLogManager()->Log(error_msg);
	}
}

CTransition* CState::AddTransition(const std::string &Name, CState* NewState, const bool &HasExitTime, const float &ExitTime)
{
	CTransition* l_Transition = new CTransition(NewState, HasExitTime, ExitTime);
	m_Transitions.insert(std::pair<const std::string, CTransition*>(Name, l_Transition));
	return l_Transition;
}

void CState::OnUpdate(float ElapsedTime)
{
	try
	{
		if (!m_OnExit.empty())
			luabind::call_function<void>(CEngine::GetSingleton().GetScriptManager()->GetLuaState(),
			m_OnExit.c_str(), m_AnimatorController->GetOwner());
	}
	catch (const luabind::error &e)
	{
		//luabind::object error_msg(luabind::from_stack(e.state(), -1));
		//CEngine::GetSingleton().GetLogManager()->Log(error_msg);
	}

	std::map<const std::string, CTransition*>::iterator itMap;

	for (itMap = m_Transitions.begin(); itMap != m_Transitions.end(); ++itMap)
	{
		if ((itMap->second->MeetsConditions()))
		{
			m_AnimatorController->ChangeCurrentState(itMap->second->GetNewState());
		}
	}
}

