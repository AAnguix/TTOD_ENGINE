#ifndef _STATE_H
#define _STATE_H

#include <string>
#include <map>
#include <vector>
#include "Animation\AnimatorControllerIntegerParameter.h"
#include "Animation\AnimatorControllerFloatParameter.h"
#include "Animation\AnimatorControllerBoolParameter.h"
#include "Animation\AnimatorControllerTriggerParameter.h"
class CTransition;

class CAnimatorController;

class CState 
{

private:
	CAnimatorController* m_AnimatorController;

	std::string m_Name;
	float m_Speed;
	std::string m_Animation;
	std::map<const std::string, CTransition*> m_Transitions;

	std::string m_OnEnter;
	std::string m_OnUpdate;
	std::string m_OnExit;

public:
	CState(CAnimatorController*, const std::string &Name, const std::string &Animation, const float &Speed, const std::string &OnEnter, const std::string &OnUpdate, const std::string &OnExit);
	virtual ~CState();
	CTransition* AddTransition(const std::string &Name, CState* NewState, const bool &HasExitTime, const float &ExitTime);
	void OnEnter();
	void OnUpdate(float ElapsedTime);
	void OnExit();

	CAnimatorController* GetOwnAnimatorController() const { return m_AnimatorController; };
};

#endif